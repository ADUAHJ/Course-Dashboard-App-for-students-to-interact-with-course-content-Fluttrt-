import 'package:flutter/material.dart';

void main() {
  runApp(CourseDashboardApp());
}

class CourseDashboardApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Course Dashboard',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: CourseDashboardHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class CourseDashboardHome extends StatefulWidget {
  @override
  _CourseDashboardHomeState createState() => _CourseDashboardHomeState();
}

class _CourseDashboardHomeState extends State<CourseDashboardHome> {
  int _selectedIndex = 0;
  String selectedCategory = "None";

  List<Map<String, String>> courses = [
    {"name": "Python Programming", "instructor": "Dr. Ayitey"},
    {"name": "Android Development Applicaiton", "instructor": "Prof. Botchway"},
    {"name": "Research Methods", "instructor": "Dr. Berko"},
    {"name": "Information Security", "instructor": "Dr. Mensah"},
    {"name": "Biology", "instructor": "Prof. White"},
  ];

  double buttonSize = 60.0;

  void _onNavTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Widget _buildBody() {
    switch (_selectedIndex) {
      case 0:
        return Center(child: Text("Home", style: TextStyle(fontSize: 24)));
      case 1:
        return _buildCourseList();
      case 2:
        return _buildProfile();
      default:
        return Container();
    }
  }

  Widget _buildCourseList() {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            itemCount: courses.length,
            itemBuilder: (context, index) {
              return ListTile(
                leading: Icon(Icons.book, color: Colors.blue),
                title: Text(courses[index]['name']!),
                subtitle: Text("Instructor: ${courses[index]['instructor']}"),
              );
            },
          ),
        ),
        SizedBox(height: 10),
        Text("Select Course Category:"),
        DropdownButton<String>(
          value: selectedCategory == "None" ? null : selectedCategory,
          hint: Text("Choose category"),
          items: ["Science", "Arts", "Technology"].map((cat) {
            return DropdownMenuItem(
              value: cat,
              child: Text(cat),
            );
          }).toList(),
          onChanged: (value) {
            setState(() {
              selectedCategory = value!;
            });
          },
        ),
        SizedBox(height: 10),
        Text("Selected Category: $selectedCategory",
            style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 20),
      ],
    );
  }

  Widget _buildProfile() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text("Profile Page", style: TextStyle(fontSize: 24)),
        SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            _showLogoutDialog();
          },
          child: Text("Logout"),
        ),
        SizedBox(height: 40),
        GestureDetector(
          onTap: () {
            setState(() {
              buttonSize = buttonSize == 60 ? 100 : 60;
            });
          },
          child: AnimatedContainer(
            duration: Duration(milliseconds: 300),
            width: buttonSize,
            height: buttonSize,
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                "Enroll",
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Logout"),
        content: Text("Are you sure you want to exit the app?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text("No"),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text("Yes"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Course Dashboard"),
      ),
      body: _buildBody(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onNavTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "Courses"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}
